// which service it is
describe("ShoppingService", () => {
  // Which function
  describe("PlaceOrder", () => {
    // Which Scenario we are testing
    test("validate user inputs", () => {});

    test("Validate response", async () => {});
  });
});

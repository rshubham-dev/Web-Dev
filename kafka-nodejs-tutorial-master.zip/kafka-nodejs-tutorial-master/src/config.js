module.exports = {
  kafka: {
    TOPIC: 'test',
    BROKERS: ['localhost:9092'],
    GROUPID: 'bills-consumer-group',
    CLIENTID: 'sample-kafka-client'
  }
}
